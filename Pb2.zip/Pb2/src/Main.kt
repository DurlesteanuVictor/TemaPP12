import java.io.File

fun CaesarCipherEncrypt(text:String, offset:Int) : String
{
    return text.map { char -> when
        {
            char.isUpperCase() -> ((char - 'A' + offset) % 26 + 'A'.code).toChar()
            char.isLowerCase() -> ((char - 'a' + offset) % 26 + 'a'.code).toChar()
            else -> char
        }
    }.joinToString("")
}

fun process(filePath:String, offset:Int) : String
{
    val file = File(filePath)
    val words = file.readText().split("\\s+".toRegex())

    return words.joinToString(" ") { word ->
        if (word.length in 4..7) CaesarCipherEncrypt(word, offset) else word
    }
}

fun main()
{
    print("Calea este: ") // de exemplu test.txt
    val path = readlnOrNull()!!

    print("Offsetul este: ")
    val offset = readlnOrNull()!!.toIntOrNull()!!

    println("Fisierul este procesat astfel: ${process(path, offset)}")
}