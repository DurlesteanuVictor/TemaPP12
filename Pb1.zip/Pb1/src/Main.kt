fun processList(multiplied: List<Int>) : Int {
    return multiplied.sum()
}

fun main() {
    val list = listOf(1, 21, 75, 39, 7, 2, 35, 3, 31, 7, 8)

    val filtered = list.filter{ it >= 5 }
    println("Eliminarea numerelor < 5: $filtered")

    val grouped = filtered.chunked(2)
    println("Gruparea în perechi: $grouped")

    val multiplied = grouped.mapNotNull{ if(it.size == 2) it[0] * it[1] else null }
    println("Multiplicarea perechilor: $multiplied")

    val result = processList(multiplied)
    println("Suma finala: $result")
}